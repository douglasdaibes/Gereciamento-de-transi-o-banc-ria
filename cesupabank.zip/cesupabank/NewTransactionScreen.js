import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

const NewTransactionScreen = ({ route }) => {
  // Estados para armazenar a descrição e o valor da nova transação
  const [descricao, setDescricao] = useState('');
  const [valor, setValor] = useState('');

  // Função de adicionar transação passada como parâmetro de navegação
  const { handleNovaTransacao } = route.params;

  // Função para lidar com a adição de uma nova transação
  const handleAdicionarTransacao = () => {
    if (!descricao || !valor) {
      // Lógica de tratamento de erro se os campos estiverem vazios
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    const valorNumerico = parseFloat(valor);

    if (isNaN(valorNumerico)) {
      // Lógica de tratamento de erro para valor não numérico
      Alert.alert('Erro', 'Por favor, insira um valor numérico válido.');
      return;
    }

    // Cria um objeto representando a nova transação
    const novaTransacao = { descricao, valor: valorNumerico };
    
    // Chama a função fornecida para lidar com a nova transação
    handleNovaTransacao(novaTransacao);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Nova Transação</Text>
      <TextInput
        style={styles.input}
        placeholder="Descrição"
        value={descricao}
        onChangeText={(text) => setDescricao(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Valor"
        value={valor}
        onChangeText={(text) => setValor(text)}
        keyboardType="numeric"
      />
      <Button title="Adicionar Transação" onPress={handleAdicionarTransacao} />
    </View>
  );
};

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#0B2559',
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
  },
});

export default NewTransactionScreen;
