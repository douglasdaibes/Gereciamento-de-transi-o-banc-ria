import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const TransactionDetailsScreen = ({ route }) => {
  // Obtém os detalhes da transação passados como parâmetro de navegação
  const { descricao, valor } = route.params.transaction;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Detalhes da Transação:</Text>
      <Text style={styles.details}>Descrição: {descricao}</Text>
      <Text style={styles.details}>Valor: R$ {valor}</Text>
    </View>
  );
};

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  details: {
    fontSize: 16,
    marginBottom: 10,
  },
});

export default TransactionDetailsScreen;
