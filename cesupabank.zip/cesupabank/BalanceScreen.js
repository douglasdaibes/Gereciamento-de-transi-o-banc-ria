import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, FlatList } from 'react-native';

const BalanceScreen = ({ navigation }) => {
  // Estado para armazenar o saldo atual
  const [saldoAtual, setSaldoAtual] = useState(5000);

  // Estado para armazenar as transações recentes
  const [transacoesRecentes, setTransacoesRecentes] = useState([
    { descricao: 'Compra no mercado', valor: -50 },
    { descricao: 'Depósito', valor: 200 },
    { descricao: 'Assinaturas mensais', valor: -90 },
    { descricao: 'Depósito mensal', valor: 4090 },
  ]);

  // Função para lidar com uma nova transação
  const handleNovaTransacao = (novaTransacao) => {
    setSaldoAtual((saldo) => saldo + novaTransacao.valor);
    setTransacoesRecentes((transacoes) => [novaTransacao, ...transacoes]);
    navigation.goBack();
  };

  // Efeito para obter o saldo inicial (executado apenas uma vez na montagem)
  useEffect(() => {
    const obterSaldoInicial = async () => {
      try {
        // Substitua pela chamada à sua API ou serviço para obter o saldo inicial
        const response = await suaApi.obterSaldoInicial();

        // Atualiza o estado com o saldo inicial obtido
        setSaldoAtual(response.saldo);
      } catch (error) {
        console.error('Erro ao obter o saldo inicial:', error.message);
        // Lógica de tratamento de erro, se necessário
      }
    };

    // Chama a função para obter o saldo inicial
    obterSaldoInicial();
  }, []); // O segundo argumento [] indica que este efeito só será executado uma vez

  // Função para renderizar cada item na lista de transações
  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.transacaoItem}
      onPress={() => navigation.navigate('DetalhesTransacao', { transaction: item })}
    >
      <Text>{item.descricao}</Text>
      <Text style={{ color: item.valor < 0 ? 'red' : 'green' }}>
        {item.valor > 0 ? '+' : ''}R$ {item.valor}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.saldo}>Saldo Atual: R$ {saldoAtual}</Text>
      <Text style={styles.transacoesHeader}>Transações Recentes:</Text>
      <FlatList
        data={transacoesRecentes}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
      <Button
        title="Nova Transação"
        onPress={() => navigation.navigate('NovaTransacao', { handleNovaTransacao })}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  saldo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  transacoesHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  transacaoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    marginBottom: 5,
    borderWidth: 1,
    borderColor: '#0B2559',
    borderRadius: 5,
    backgroundColor: '#fff',
  },
});

export default BalanceScreen;
