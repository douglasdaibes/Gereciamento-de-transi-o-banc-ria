// Importa o React e os componentes necessários do React Native
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Importa os componentes de cada tela do aplicativo
import BalanceScreen from './BalanceScreen';
import NewTransactionScreen from './NewTransactionScreen';
import TransactionDetailsScreen from './TransactionDetailsScreen';

// Cria uma pilha de navegação usando o createStackNavigator do React Navigation
const Stack = createNativeStackNavigator();

// Componente principal do aplicativo
const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="BalanceScreen" // Define a tela inicial da navegação
        screenOptions={{
          headerStyle: {
            backgroundColor: '#38184C', // Cor de fundo da barra de navegação
          },
          headerTintColor: '#fff', // Cor do texto da barra de navegação
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        {/* Configuração das telas dentro da pilha de navegação */}
        <Stack.Screen
          name="BalanceScreen"
          component={BalanceScreen}
          options={{ title: 'CesupaBank' }}
        />
        <Stack.Screen
          name="NovaTransacao"
          component={NewTransactionScreen}
          options={{ title: 'Nova Transação' }}
        />
        <Stack.Screen
          name="DetalhesTransacao"
          component={TransactionDetailsScreen}
          options={{ title: 'Detalhes da Transação:' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Exporta o componente principal do aplicativo
export default App;
